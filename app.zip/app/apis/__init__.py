# app/apis/__init__.py
"""
API router handlers for AgriSmart backend
"""