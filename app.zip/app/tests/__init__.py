"""
Test suite for AgriSmart backend.
"""