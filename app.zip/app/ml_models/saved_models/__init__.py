# app/ml_models/saved_models/__init__.py
"""
Trained ML models storage
"""