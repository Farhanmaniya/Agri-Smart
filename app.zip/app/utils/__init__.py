# app/utils/__init__.py
"""
Utility functions and helpers
"""